/**
 * 
 */
/**
 * @author Silvia
 *
 */
module Blanca_Penabad_Villar {
	requires java.xml;
}