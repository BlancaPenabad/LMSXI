package actividad5_0_1;

import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;




	public class Actividad5_0_1 {
	


		public static void main(String[] args) {
			String filexml = "./src/actividad5_0_1/estudiantes.xml";
			
			try {
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				DocumentBuilder db = dbf.newDocumentBuilder();
				Document doc = db.parse(filexml);
				
				procesaDigital(doc);
				
			} catch (ParserConfigurationException | SAXException | IOException e) {
				
				e.printStackTrace();
			}
		}
		
		private static void procesaDigital (Document doc) {
			Element estudiantes = doc.getDocumentElement();
			
			NodeList listaEstudiantes = estudiantes.getChildNodes();
			
			
			for (int i = 0; i < listaEstudiantes.getLength(); i++) {
				Node estudiante = listaEstudiantes.item(i);
				if (estudiante.getNodeType() == Node.ELEMENT_NODE) {
					
				Element elementEstudiante = (Element)estudiante;
				
				Boolean aprobado = Boolean.parseBoolean(elementEstudiante.getAttribute("aprobado"));
			
				if(aprobado) {
					System.out.println(elementEstudiante.getElementsByTagName("nombre").item(0).getTextContent());
					
				}
				
				
				
				}
				
			}
		}

	}


