package actividad5_0_2;

import java.io.File;

import org.xml.sax.helpers.DefaultHandler;


public class Actividad5_0_2 extends DefaultHandler{
	private StringBuffer sb;
	
	public static void main (String[] args) {
		
		
		
		SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
		
		try {
			SAXParser parser = saxParserFactory.newSAXParser();
			DefaultHandler handler = new Actividad5_0_2 ();
			
			File f = new File("./src/actividad5_0_2/estudiantes.xml");
			
			parser.parse(f, handler);
			
			
			
		} catch (ParserConfigurationException | SAXException | IOException e) {
			
			e.printStackTrace();
		}
		
		
		
	}



}
